from database import create_db, get_banks
from bot import start
create_db()
get_banks()
start()